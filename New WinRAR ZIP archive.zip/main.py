from flask import Flask, render_template,request
import mysql.connector

app=Flask(__name__,template_folder='template')

conn=mysql.connector.connect(host="",user="",password="",database="")
cursor=conn.cursor


@app.route('/')
def login():
     return render_template('login.html')

@app.route('/register')
def about():
     return render_template('register.html')
@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/home')
def home():
    return render_template('home.html')
@app.route('/login_validation',methods=['Post'])
def login_validation():
    email=request.form.get('email')
    password=request.form.get('password')
    cursor.execute("""SELECT*from users 'users' WHERE 'email' LIke'{}' 'password' LIKE'{}'""" .format(email.password))
    cursor.fetchall()
    if len(users)>0:
        return render_template('home.html')
     esle:
          return render_template('login.html')
@app.route('/add_user',method=['Post'])
def add_user():
    name=request.form.get('uname')
    name=request.form.get('uemail')
    password=request.form.get('upassword')
    cursor.execute("""INSERT INTO 'users' ('user_id','name','email','password')VALUES(Null,'{}','{},'{}')""".format(name, email ,password))
    conn.commit()
    return "..."

    return"The email is  {} and the password is  {}".format(email,password)


if __name__=="__main__":
    app.run (debug=True)


